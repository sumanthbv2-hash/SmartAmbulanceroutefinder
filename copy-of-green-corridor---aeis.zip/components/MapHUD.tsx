import React from 'react';
import { MissionStatus, TrafficLightState } from '../types';

interface Props {
  status: MissionStatus;
  speed: number;
  eta: string;
  distance: string;
  trafficState: TrafficLightState;
}

const MapHUD: React.FC<Props> = ({ status, speed, eta, distance, trafficState }) => {
  return (
    <div className="absolute top-4 left-4 right-4 pointer-events-none z-[1000] flex justify-between items-start">
      {/* Top Left: Status */}
      <div className="bg-black/80 border border-neon-green p-4 rounded-br-2xl backdrop-blur-md shadow-[0_0_15px_rgba(0,255,157,0.3)]">
        <div className="text-xs text-neon-green/70 mb-1">MISSION STATUS</div>
        <div className="text-xl font-bold font-mono text-white animate-pulse">
          {status.replace('_', ' ')}
        </div>
      </div>

      {/* Top Center: Traffic Light Status */}
      <div className="flex flex-col items-center gap-2">
        <div className={`px-6 py-2 rounded-full border-2 font-bold backdrop-blur-xl shadow-lg transition-all duration-500 ${
          trafficState === TrafficLightState.GREEN_CORRIDOR_ACTIVE 
            ? 'bg-neon-green/20 border-neon-green text-neon-green shadow-[0_0_30px_#00ff9d]' 
            : trafficState === TrafficLightState.RED 
            ? 'bg-red-900/50 border-alert-red text-alert-red' 
            : 'bg-yellow-900/50 border-yellow-500 text-yellow-500'
        }`}>
          {trafficState === TrafficLightState.GREEN_CORRIDOR_ACTIVE ? (
            <span className="flex items-center gap-2">
              <i className="fas fa-bolt"></i> GREEN WAVE ACTIVE
            </span>
          ) : (
             <span>TRAFFIC SIGNAL: {trafficState}</span>
          )}
        </div>
      </div>

      {/* Top Right: Telemetry */}
      <div className="bg-black/80 border border-neon-blue p-4 rounded-bl-2xl backdrop-blur-md text-right shadow-[0_0_15px_rgba(0,243,255,0.3)]">
        <div className="grid grid-cols-2 gap-x-6 gap-y-2">
          <div>
            <div className="text-[10px] text-neon-blue/70">SPEED</div>
            <div className="text-xl font-mono text-white">{speed} <span className="text-sm opacity-50">km/h</span></div>
          </div>
          <div>
            <div className="text-[10px] text-neon-blue/70">DISTANCE</div>
            <div className="text-xl font-mono text-white">{distance}</div>
          </div>
          <div className="col-span-2 border-t border-white/10 pt-2 mt-1">
            <div className="text-[10px] text-neon-blue/70">EST. ARRIVAL</div>
            <div className="text-2xl font-mono text-neon-blue">{eta}</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MapHUD;
