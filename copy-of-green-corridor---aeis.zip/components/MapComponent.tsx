import React, { useEffect, useRef } from 'react';
import { Coordinate, MissionStatus, TrafficLightState } from '../types';

// Declare Leaflet global
declare const L: any;

interface Props {
  ambulancePos: Coordinate;
  targetPos: Coordinate | null;
  status: MissionStatus;
  onRouteFound: (summary: any) => void;
  onPositionUpdate: (pos: Coordinate) => void;
  onDistanceUpdate?: (meters: number) => void;
  onTrafficSignalUpdate: (state: TrafficLightState) => void;
  onArrival: () => void;
}

interface SignalMarker {
  index: number;
  pos: Coordinate;
  state: TrafficLightState;
  marker: any;
}

const MapComponent: React.FC<Props> = ({ 
  ambulancePos, 
  targetPos, 
  status, 
  onRouteFound,
  onPositionUpdate,
  onDistanceUpdate,
  onTrafficSignalUpdate,
  onArrival
}) => {
  const mapRef = useRef<any>(null);
  const routingControlRef = useRef<any>(null);
  const ambulanceMarkerRef = useRef<any>(null);
  const targetMarkerRef = useRef<any>(null);
  const signalMarkersRef = useRef<SignalMarker[]>([]);
  const currentTrafficStateRef = useRef<TrafficLightState>(TrafficLightState.GREEN);
  const mapContainerId = 'leaflet-map-container';
  
  // Animation refs
  const animationRef = useRef<number | null>(null);
  const routePathRef = useRef<Coordinate[]>([]);
  const progressRef = useRef<number>(0);
  const totalDistanceRef = useRef<number>(0);

  // Helper: Calculate Bearing for Vehicle Rotation
  const getBearing = (startLat: number, startLng: number, destLat: number, destLng: number) => {
    const startLatRad = startLat * (Math.PI / 180);
    const startLngRad = startLng * (Math.PI / 180);
    const destLatRad = destLat * (Math.PI / 180);
    const destLngRad = destLng * (Math.PI / 180);

    const y = Math.sin(destLngRad - startLngRad) * Math.cos(destLatRad);
    const x = Math.cos(startLatRad) * Math.sin(destLatRad) -
              Math.sin(startLatRad) * Math.cos(destLatRad) * Math.cos(destLngRad - startLngRad);
    
    let brng = Math.atan2(y, x);
    brng = (brng * 180) / Math.PI;
    return (brng + 360) % 360;
  };

  // Initialize Map
  useEffect(() => {
    if (!mapRef.current) {
      const map = L.map(mapContainerId, {
        zoomControl: false,
        attributionControl: false
      }).setView([ambulancePos.lat, ambulancePos.lng], 14);

      // Dark/Futuristic Map Tiles
      L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        maxZoom: 20,
        subdomains: 'abcd'
      }).addTo(map);

      // Ambulance Icon
      const ambulanceIcon = L.divIcon({
        className: 'ambulance-marker-icon',
        html: `<div id="ambulance-vehicle" class="relative w-12 h-12 flex items-center justify-center transition-transform duration-300">
                <div class="absolute inset-0 bg-blue-500/20 rounded-full animate-pulse"></div>
                <div class="z-20 w-8 h-10 bg-black border-2 border-neon-blue rounded-sm shadow-[0_0_15px_#00f3ff] flex flex-col items-center justify-between py-1">
                   <div class="w-full h-1 bg-neon-blue/50"></div>
                   <i class="fas fa-ambulance text-white text-xs"></i>
                   <div class="w-full h-0.5 bg-red-500/80"></div>
                </div>
               </div>`,
        iconSize: [48, 48],
        iconAnchor: [24, 24]
      });

      ambulanceMarkerRef.current = L.marker([ambulancePos.lat, ambulancePos.lng], { 
        icon: ambulanceIcon,
        zIndexOffset: 1000 
      }).addTo(map);
      
      mapRef.current = map;
    }

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, []);

  // Sync Ambulance Marker
  useEffect(() => {
    if (ambulanceMarkerRef.current && mapRef.current) {
      ambulanceMarkerRef.current.setLatLng([ambulancePos.lat, ambulancePos.lng]);
      mapRef.current.panTo([ambulancePos.lat, ambulancePos.lng], { animate: true, duration: 1.0 });
    }
  }, [ambulancePos]);

  // Handle Route Calculation & Movement
  useEffect(() => {
    if (!mapRef.current) return;

    // Cleanup previous routing/animation/signals
    cleanupRoute();

    // Reset markers if Idle
    if (status === MissionStatus.IDLE) {
      return;
    }

    // Setup Route if Target Exists and Mission Active
    if (targetPos && (status === MissionStatus.ENROUTE_PATIENT || status === MissionStatus.ENROUTE_HOSPITAL)) {
       // Add Target Marker
       const isPatient = status === MissionStatus.ENROUTE_PATIENT;
       const color = isPatient ? '#ff003c' : '#00ff9d';
       
       const targetHtml = isPatient 
        ? `<div class="relative flex items-center justify-center">
             <div class="w-10 h-10 bg-alert-red rounded-full border-2 border-white animate-bounce shadow-[0_0_30px_#ff003c] flex items-center justify-center z-10">
                <i class="fas fa-user-injured text-white text-sm"></i>
             </div>
             <div class="absolute w-20 h-20 bg-alert-red/30 rounded-full animate-ping z-0"></div>
           </div>`
        : `<div class="relative flex items-center justify-center">
             <div class="w-12 h-12 border-2 border-neon-green bg-black rounded-lg flex items-center justify-center text-neon-green font-bold text-lg shadow-[0_0_20px_#00ff9d] backdrop-blur-sm z-10">
                <i class="fas fa-hospital-symbol"></i>
             </div>
             <div class="absolute w-16 h-16 border border-neon-green/50 rounded-lg animate-ping"></div>
           </div>`;

       const targetIcon = L.divIcon({
        className: 'custom-div-icon',
        html: targetHtml,
        iconSize: [40, 40],
        iconAnchor: [20, 20]
      });
      
      targetMarkerRef.current = L.marker([targetPos.lat, targetPos.lng], { icon: targetIcon }).addTo(mapRef.current);

      // Setup Routing Machine
      const plan = L.Routing.plan(
        [
          L.latLng(ambulancePos.lat, ambulancePos.lng),
          L.latLng(targetPos.lat, targetPos.lng)
        ],
        {
          createMarker: () => null,
          addWaypoints: false,
          draggableWaypoints: false,
          fitSelectedRoutes: true
        }
      );

      routingControlRef.current = L.Routing.control({
        plan: plan,
        lineOptions: {
          styles: [{ color: color, opacity: 0.6, weight: 6, className: 'route-line' }]
        },
        show: false,
        addWaypoints: false,
        routeWhileDragging: false,
        fitSelectedRoutes: true,
      }).addTo(mapRef.current);

      // Event: Route Found
      routingControlRef.current.on('routesfound', function(e: any) {
        const routes = e.routes;
        if (routes && routes.length > 0) {
          const route = routes[0];
          onRouteFound(route.summary);
          
          totalDistanceRef.current = route.summary.totalDistance;
          routePathRef.current = route.coordinates;
          progressRef.current = 0;
          
          // Preinstall Signals along the route
          installSignals(route.coordinates);
          
          // Start Animation
          startAnimation();
        }
      });
    }

  }, [targetPos, status, ambulancePos]);

  const cleanupRoute = () => {
    if (routingControlRef.current) {
        mapRef.current.removeControl(routingControlRef.current);
        routingControlRef.current = null;
    }
    if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
        animationRef.current = null;
    }
    if (targetMarkerRef.current) {
        mapRef.current.removeLayer(targetMarkerRef.current);
        targetMarkerRef.current = null;
    }
    // Remove all signal markers
    signalMarkersRef.current.forEach(s => mapRef.current.removeLayer(s.marker));
    signalMarkersRef.current = [];
    routePathRef.current = [];
  };

  const installSignals = (coordinates: Coordinate[]) => {
      // Install 3 signals at roughly 25%, 50%, and 75% of the path to ensure interactions
      const points = [
          Math.floor(coordinates.length * 0.25),
          Math.floor(coordinates.length * 0.50),
          Math.floor(coordinates.length * 0.75)
      ];

      points.forEach(idx => {
          const pos = coordinates[idx];
          if(pos) {
              const marker = createSignalMarker(pos, TrafficLightState.RED);
              signalMarkersRef.current.push({
                  index: idx,
                  pos: pos,
                  state: TrafficLightState.RED,
                  marker: marker
              });
          }
      });
  };

  const createSignalMarker = (pos: Coordinate, state: TrafficLightState) => {
      const isGreen = state === TrafficLightState.GREEN_CORRIDOR_ACTIVE;
      const html = isGreen 
        ? `<div class="flex flex-col items-center">
            <div class="bg-black border-2 border-neon-green rounded-lg p-1 shadow-[0_0_20px_#00ff9d] transform scale-90">
                <div class="w-3 h-3 bg-red-900/30 rounded-full mb-1"></div>
                <div class="w-3 h-3 bg-yellow-900/30 rounded-full mb-1"></div>
                <div class="w-3 h-3 bg-neon-green rounded-full shadow-[0_0_15px_#00ff9d] animate-pulse"></div>
            </div>
            <div class="h-6 w-0.5 bg-neon-green shadow-[0_0_5px_#00ff9d]"></div>
           </div>`
        : `<div class="flex flex-col items-center">
            <div class="bg-black border-2 border-gray-600 rounded-lg p-1 shadow-2xl transform scale-75">
                <div class="w-3 h-3 bg-red-600 rounded-full animate-pulse shadow-[0_0_15px_#ff0000] mb-1"></div>
                <div class="w-3 h-3 bg-yellow-900/30 rounded-full mb-1"></div>
                <div class="w-3 h-3 bg-green-900/30 rounded-full"></div>
            </div>
            <div class="h-6 w-0.5 bg-gray-500"></div>
           </div>`;

      const icon = L.divIcon({
         className: 'signal-marker',
         html: html,
         iconSize: [24, 60],
         iconAnchor: [12, 60]
      });

      return L.marker([pos.lat, pos.lng], { icon, zIndexOffset: 2000 }).addTo(mapRef.current);
  };

  const updateSignalVisual = (signal: SignalMarker) => {
      mapRef.current.removeLayer(signal.marker);
      signal.marker = createSignalMarker(signal.pos, signal.state);
  };

  // Animation Logic
  const startAnimation = () => {
    let lastTimestamp = performance.now();
    let lastDistUpdate = 0;

    const animate = (timestamp: number) => {
      if (!routePathRef.current.length || !mapRef.current) return;

      const deltaTime = timestamp - lastTimestamp;
      lastTimestamp = timestamp;

      // Determine Speed based on Mission Type
      // Hospital run is significantly faster
      const speedMultiplier = status === MissionStatus.ENROUTE_HOSPITAL ? 0.015 : 0.004;
      const speed = speedMultiplier * deltaTime;

      let moving = true;
      const currentIdx = Math.floor(progressRef.current);
      const currentPos = routePathRef.current[currentIdx];

      // Update Running Distance (Throttled 200ms)
      if (timestamp - lastDistUpdate > 200) {
          if (totalDistanceRef.current > 0 && onDistanceUpdate) {
              const remainingPct = 1 - (currentIdx / routePathRef.current.length);
              const remainingMeters = totalDistanceRef.current * remainingPct;
              onDistanceUpdate(remainingMeters);
          }
          lastDistUpdate = timestamp;
      }

      // Check Signals
      if (currentPos) {
          for (const signal of signalMarkersRef.current) {
              // 1. Check if we have passed the signal (allow small buffer)
              if (currentIdx > signal.index + 3) {
                  // If passed and not Red, turn Red (Reset)
                  if (signal.state !== TrafficLightState.RED) {
                      signal.state = TrafficLightState.RED;
                      updateSignalVisual(signal);
                      // Don't update HUD traffic status here, let it remain GREEN/Active for flow
                  }
                  continue;
              }
              
              const dist = mapRef.current.distance([currentPos.lat, currentPos.lng], [signal.pos.lat, signal.pos.lng]);
              
              // Smart Trigger Distance: 150m for Green Wave
              const triggerDist = 150;

              if (dist < triggerDist) {
                  // AUTO GREEN WAVE TRIGGER
                  if (signal.state !== TrafficLightState.GREEN_CORRIDOR_ACTIVE) {
                     signal.state = TrafficLightState.GREEN_CORRIDOR_ACTIVE;
                     updateSignalVisual(signal);
                     
                     if (currentTrafficStateRef.current !== TrafficLightState.GREEN_CORRIDOR_ACTIVE) {
                         onTrafficSignalUpdate(TrafficLightState.GREEN_CORRIDOR_ACTIVE);
                         currentTrafficStateRef.current = TrafficLightState.GREEN_CORRIDOR_ACTIVE;
                     }
                  }
              } else if (dist < 20 && signal.state === TrafficLightState.RED) {
                  // Stop at Red Light (if logic fails or emergency stop needed)
                  moving = false;
                  
                  if (currentTrafficStateRef.current !== TrafficLightState.RED) {
                      onTrafficSignalUpdate(TrafficLightState.RED);
                      currentTrafficStateRef.current = TrafficLightState.RED;
                  }
              }
          }
      }

      if (moving) {
        progressRef.current += speed;

        if (progressRef.current >= routePathRef.current.length - 1) {
          const finalPos = routePathRef.current[routePathRef.current.length - 1];
          updateAmbulancePosition(finalPos.lat, finalPos.lng);
          onArrival();
          animationRef.current = null;
          return;
        }

        const nextIndex = Math.min(Math.floor(progressRef.current) + 1, routePathRef.current.length - 1);
        const nextPos = routePathRef.current[nextIndex];
        
        if (currentPos && nextPos) {
            const fraction = progressRef.current - Math.floor(progressRef.current);
            const lat = currentPos.lat + (nextPos.lat - currentPos.lat) * fraction;
            const lng = currentPos.lng + (nextPos.lng - currentPos.lng) * fraction;

            const bearing = getBearing(currentPos.lat, currentPos.lng, nextPos.lat, nextPos.lng);

            updateAmbulancePosition(lat, lng, bearing);
            onPositionUpdate({ lat, lng });
            
            // Smooth Camera Follow
            mapRef.current.panTo([lat, lng], { animate: false });
        }
      }

      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);
  };

  const updateAmbulancePosition = (lat: number, lng: number, bearing?: number) => {
    if (ambulanceMarkerRef.current) {
      ambulanceMarkerRef.current.setLatLng([lat, lng]);
      
      if (bearing !== undefined) {
         const iconElement = ambulanceMarkerRef.current.getElement();
         if (iconElement) {
             const vehicleDiv = iconElement.querySelector('#ambulance-vehicle');
             if (vehicleDiv) {
                 vehicleDiv.style.transform = `rotate(${bearing}deg)`;
             }
         }
      }
    }
  };

  return <div id={mapContainerId} className="w-full h-full z-0 bg-black" />;
};

export default MapComponent;