import React, { useEffect, useRef } from 'react';
import { AILog } from '../types';

interface Props {
  logs: AILog[];
}

const AILogPanel: React.FC<Props> = ({ logs }) => {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  return (
    <div className="h-full flex flex-col bg-panel-bg border-l border-neon-green/30 backdrop-blur-sm">
      <div className="p-3 border-b border-neon-green/30 bg-black/40">
        <h3 className="text-neon-green font-mono text-sm flex items-center gap-2">
          <i className="fas fa-microchip"></i> AI SYSTEM LOGS
        </h3>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-3 font-mono text-xs">
        {logs.map((log) => (
          <div key={log.id} className={`p-2 border-l-2 bg-black/20 ${
            log.type === 'warning' ? 'border-alert-red text-red-200' :
            log.type === 'success' ? 'border-neon-green text-green-100' :
            log.type === 'analysis' ? 'border-neon-blue text-cyan-100' :
            'border-gray-500 text-gray-400'
          }`}>
            <div className="opacity-50 text-[10px] mb-1">{log.timestamp}</div>
            <div className="leading-relaxed">{log.message}</div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>
    </div>
  );
};

export default AILogPanel;
