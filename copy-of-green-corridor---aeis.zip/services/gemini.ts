import { GoogleGenAI } from "@google/genai";

const getGeminiClient = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

export const analyzeEmergency = async (
  emergencyType: string,
  severity: string,
  trafficCondition: string
): Promise<string> => {
  try {
    const ai = getGeminiClient();
    const prompt = `
      You are the AI Core of the "Green Corridor" Emergency Navigation System.
      
      Current Mission Status:
      - Emergency Type: ${emergencyType}
      - Severity: ${severity}
      - Traffic Conditions: ${trafficCondition}

      Generate a short, tactical, futuristic status report (max 3 sentences). 
      Focus on route optimization, traffic signal override status, and medical advisory.
      Do not use markdown. Speak like a machine interface.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "SYSTEM WARNING: AI ANALYTICS OFFLINE. MANUAL OVERRIDE SUGGESTED.";
  } catch (error) {
    console.error("Gemini AI Error:", error);
    return "CONNECTION ERROR: UNABLE TO CONTACT AI CORE.";
  }
};
